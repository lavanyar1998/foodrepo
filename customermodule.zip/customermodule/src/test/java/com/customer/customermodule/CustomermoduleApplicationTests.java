package com.customer.customermodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomermoduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
