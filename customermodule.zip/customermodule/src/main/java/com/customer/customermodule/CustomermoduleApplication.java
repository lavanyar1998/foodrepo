package com.customer.customermodule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomermoduleApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomermoduleApplication.class, args);
	}

}
